const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const {DynamoDB} = require('@aws-sdk/client-dynamodb-v2-node');


require('dotenv').config();

const app = express();
const port = process.env.PORT || 5000;
const uri = process.env.ATLAS_URI;
const fs = require('fs');
const client = new DynamoDB({region: 'us-east-2'});

app.use(cors());
app.use(express.json());

async function connectdyno() {
 try {
    const results = await client.listTables({});
    console.log(results.TableNames.join('\n'));
      } catch (err) {
    console.error(err);
	  }
  }

connectdyno();	

async function getitemsdyno() {
var params = {
    TableName : 'requirements',
    KeyConditionExpression: 'requirementId = :ridval',
    ExpressionAttributeValues: {
        ':ridval': { 'S' : '9999-1' }
    }	
};

await client.query(params, function(err, data) {
    if (err) {
        console.error("Unable to query. Error:", JSON.stringify(err, null, 2));
    } else {
        console.log("Query succeeded.");
        data.Items.forEach(function(item) {
            console.log("data:", item);
        });
    }
});
}

getitemsdyno();

/*
async function scanitemsdyno() {
var params = {
    TableName : "requirements",
	
};

let scanpromise = client.scan(params).promise();
let scanresults = await scanpromise;
let scandata = scanresults.items;
console.log("Scan Query succeeded.");
console.log("data:", scandata);
}

scanitemsdyno();
*/


	


mongoose.connect(uri, 
	{useNewUrlParser: true, 
		useCreateIndex: true, 
		useUnifiedTopology: true,
		sslCA: [fs.readFileSync("rds-combined-ca-bundle.pem")]
	});

/*
mongoose.connect("mongodb+srv://sxappala:sxappala@srini-mongogcp.uv7qu.gcp.mongodb.net/customers?retryWrites=true&w=majority",
useNewUrlParser: true,
useCreateIndex: true,
useUnifiedTopology: true,
)
*/

const connection = mongoose.connection;

connection.once('open', () => {
    console.log('Mongo DB Connection Successful....');
});

const requirementRouter = require('./routes/requirement');
app.use('/requirement', requirementRouter);


app.listen(port, () => {
    console.log('App server is running.' + port);
})

