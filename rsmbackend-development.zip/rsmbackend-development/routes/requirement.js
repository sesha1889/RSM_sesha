const router = require('express').Router();
let Requirement = require('../model/requirement');
const { find, db } = require('../model/requirement');

router.route('/home').get((req, res) => {
  console.log('Entered into Get Home API call...');
  Requirement.aggregate(
      [
        {
          $match: 
          { requirementSts : /open/i }
        },   
        {
          $group:
            {
              _id: "$primarySkills", 
              primarySkills : { $min: "$primarySkills"},
              totalopenPositions: { $sum: "$openPosition" },
              totalfilledPositions: { $sum: "$filledPositions" },
              totalprofilesReceived: { $sum: "$profilesReceived" },
              totalprofilesSubmitted: { $sum: "$profilesSubmitted" },
              totalpendClientInterview: { $sum: "$pendClientInterview" },
              totalclientRejected: { $sum: "$clientRejected" }
            }
        },
        {
          $project:
            {
              _id : 0,
              "primarySkills" : 1,
              "totalopenPositions" : 1, 
              "totalfilledPositions" : 1,
              "totalprofilesReceived" : 1,
              "totalprofilesSubmitted" : 1,
              "totalpendClientInterview" : 1,
              "totalclientRejected" : 1,
            }
        },
        {
          $sort: 
            {
              "primarySkills" : 1
            }
        }
      ]
   )
  .then(requirement => res.json(requirement))
  .catch(err => res.status(400).json('Error' + err));
});

router.route('/').get((req, res) => {

  Requirement.find({}, {_id: 0})
    .then(requirement => res.json(requirement))
    .catch(err => res.status(400).json('Error:' + err))
});

router.route('/:status').get((req, res) => {
  const status = new RegExp(req.params.status, 'i');
  const query = { requirementSts: status };
  Requirement.find(query, {_id: 0})
    .then(requirement => res.json(requirement))
    .catch(err => res.status(400).json('Error:' + err))
});

router.route('/add').post((req, res) => {
  console.log('Entered into Add Requirement API call...');
  const requirementId = req.body.requirementId;
  const winzoneID = req.body.winzoneID;
  const openDate = new Date(req.body.openDate);
  const statementOrder = Number(req.body.statementOrder);
  const department = req.body.department;
  const jobTitle	= req.body.jobTitle;	
  const primarySkills = req.body.primarySkills;
  const jobDescription = req.body.jobDescription;
  const startDate = new Date(req.body.startDate);	
  const durationPeriod = req.body.durationPeriod;
  const requirementSts = req.body.requirementSts;
  const clientRate = Number(req.body.clientRate);
  const vendorRate = Number(req.body.vendorRate);	
  const openPosition = Number(req.body.openPosition);	
  const filledPositions = Number(req.body.filledPositions);
  const profilesReceived = Number(req.body.profilesReceived);
  const profilesSubmitted = Number(req.body.profilesSubmitted);
  const pendClientInterview = Number(req.body.pendClientInterview);
  const clientRejected = Number(req.body.clientRejected);
  const resourceInformation = req.body.resourceInformation;

  const newRequirement = new Requirement ({
      requirementId,
      winzoneID,
      openDate,
      statementOrder,
      department,
      jobTitle,
      primarySkills,
      jobDescription,
      startDate,
      durationPeriod,
      requirementSts,
      clientRate,
      vendorRate,
      openPosition,
      filledPositions,
      profilesReceived,
      profilesSubmitted,
      pendClientInterview,
      clientRejected,
      resourceInformation
  });

  newRequirement.save()
  .then(() => res.json('Requirement is added'))
  .catch(err => res.status(400).json('Error:' + err));
});

//Update requirement based on the ID
router.route('/update/:id').post((req,res) => {
  const query = { requirementId: req.params.id };
  Requirement.findOne(query).then(requirement =>{
    requirement.requirementId = req.body.requirementId;
    requirement.winzoneID = req.body.winzoneID;
    requirement.openDate = req.body.openDate;
    requirement.statementOrder = req.body.statementOrder,
    requirement.department = req.body.department;
    requirement.jobTitle = req.body.jobTitle;
    requirement.primarySkills = req.body.primarySkills;
    requirement.jobDescription = req.body.jobDescription;
    requirement.startDate = req.body.startDate;
    requirement.durationPeriod = req.body.durationPeriod;
    requirement.requirementSts = req.body.requirementSts;
    requirement.clientRate = req.body.clientRate;
    requirement.vendorRate = req.body.vendorRate;
    requirement.openPosition = req.body.openPosition;
    requirement.filledPositions = req.body.filledPositions;
    requirement.profilesReceived = req.body.profilesReceived;
    requirement.profilesSubmitted = req.body.profilesSubmitted;
    requirement.pendClientInterview = req.body.pendClientInterview;
    requirement.clientRejected = req.body.clientRejected;
    requirement.resourceInformation = req.body.resourceInformation

    requirement.save()
      .then(() => res.json('Requirement is updated'))
      .catch(err => res.status(400).json('Error:' + err))
  }).catch(err => res.status(400).json('Error:' + err))
});


module.exports = router;
