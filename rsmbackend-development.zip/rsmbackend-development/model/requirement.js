const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const requirementSchema = new Schema({
    requirementId : { type: String, required: true, index: true, unique:true},
    openDate: { type: Date, required: true },
    statementOrder: { type: Number },
    winzoneID: { type: String },
    department: { type: String, required: true },
    jobTitle: { type: String, required: true },
    primarySkills: { type: String, required: true },
    jobDescription: { type: String, required: true },
    startDate: { type: Date, required: true },
    durationPeriod: { type: String, required: true }, 
    requirementSts: { type: String, required: true },  
    clientRate: { type: Number, required: true },      
    vendorRate: { type: Number },      
    openPosition: { type: Number, required: true },      
    filledPositions: { type: Number },       
    profilesReceived: { type: Number },      
    profilesSubmitted: { type: Number },      
    pendClientInterview: { type: Number },      
    clientRejected: { type: Number },      
    resourceInformation: { type: Object}
  });

  const Requirementmodel = mongoose.model('requirements', requirementSchema);

  module.exports = Requirementmodel;
