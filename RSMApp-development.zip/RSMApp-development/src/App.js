import React from "react";
import logo from "./logo.svg";
import "./App.css";
import Navbar from "./components/navbar/Nav";
import SideBar from "./components/navbar/sidebar";
import HomeDashboard from "./components/home/homedashboard";
import Requirements from "./components/reqDetails/reqDetails";
import Clock from "./components/clock/clock";

import { BrowserRouter as Router, Switch, Route } from "react-router-dom";

function App() {
  return (
    <div>
      <SideBar />

      <Navbar />

      <Clock />
      <main style={{ marginTop: "16px" }}>
    
        <Router>
          <Switch>
            <Route exact path="/" component={HomeDashboard}></Route>
            <Route exact path="/Home" component={HomeDashboard}></Route>
            <Route path="/Requirements" component={Requirements}></Route>
          </Switch>
        </Router> 
      </main>
    </div>
  );
}

export default App;
