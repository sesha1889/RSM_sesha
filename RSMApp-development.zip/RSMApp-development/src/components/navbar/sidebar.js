import React, { Component } from "react";
import { slide as Menu } from "react-burger-menu";
import "./sidebar.css";

class sidebar extends Component{
  constructor(props){
    super(props);
  this.state ={
    selectedItem:'home'
  }
}
  menuSelected(selectedItem)
  {
    this.setState({selectedItem:selectedItem})
  }
  render() {
    let selectedItem ='home';
    if(window.location.pathname == "/Requirements"){
      selectedItem='requirement';
    }

    return(
    <Menu width={"250px"}>
      <a className={selectedItem==='home'?'selected-navItem':''} href="/Home" onClick={()=>this.menuSelected('home')} >
       Dashboard      </a>

      <a className={selectedItem==='requirement'?'selected-navItem':''} href="/Requirements" onClick={()=>this.menuSelected('requirement')}>
        Manage
      </a>
    </Menu>
     ) };


}
export default sidebar;