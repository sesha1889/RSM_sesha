import React, { Component } from 'react';
import './Nav.css';
import Logo from "../Logo/Logo";
import '../Logo/Logo.css'
import ctsLogo from ".././Logo/CTS_Logo.jpg"

class Navbar extends Component {
    state = {
      selectedPage: "Home",
    };
  
    render() {
      let selectedPage = "Home";
      if (window.location.pathname == "/Requirements") {
        selectedPage = "Requirements";
      }
      return (
    <header className="navbar" style={{width:"100%"}}>
        <nav className="navbarNavigation">
            <div className="navigationitems">
                
            <ul>
                <li>
                    
                   
                  <table width="100%">
                      <tr>
                          <td width="25%">
                              <a><img src ={ctsLogo} className="logoAlign" alt="CTS_Logo"></img> </a></td>
                      <td  className="headerAlign">
                  {selectedPage === "Home" ? "Lowe's Resourcing and Hiring Dashboard" : ""}
                  {selectedPage === "Requirements" ? "Manage Positions" : ""}</td>
                  </tr>
                  </table>
               
                </li>
            </ul>

            
            </div>
        </nav>
    </header>
      );
      }
    }

export default Navbar;