import React from 'react';
import { render } from 'react-dom';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import "../reqDetails/reqDetails.css";
import Button from '@material-ui/core/Button';
import IconButton from '@material-ui/core/IconButton';
import CloudDownload from '@material-ui/icons/CloudDownload';
import './home.css';
/*import 'ag-grid-enterprise';*/


class HomeDashboard extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        columnDefs: [
          {headerName: "Skill", field: "primarySkills", tooltipField: "primarySkills",minWidth: '400',sortable:true, filter:true},
          {headerName: "Open Positions", field: "totalopenPositions", sortable:true, filter:true,cellClass: "grid-cell-right" }, 
          {headerName: "Filled Positions", field: "totalfilledPositions", sortable:true, filter:true,cellClass: "grid-cell-right"}, 
          {headerName: "Candidate Profiles Received", field: "totalprofilesReceived",  sortable:true, filter:true,cellClass: "grid-cell-right"}, 
          {headerName: "Candidate Profiles Submitted", field: "totalprofilesSubmitted", sortable:true, filter:true,cellClass: "grid-cell-right"},
          {headerName: "Waiting Client Interview", field: "totalpendClientInterview", sortable:true, filter:true,cellClass: "grid-cell-right" }, 
          {headerName: "Rejected By Client", field: "totalclientRejected", sortable:true, filter:true,cellClass: "grid-cell-right"}
          
        ],
        defaultColDef: {
          flex: 1,
          minWidth: '90',
          //autoWidth:true,
          maxWidth:'400',
          //maxRowHeight:'90',
          cellClass: 'cell-wrap-text',
          //autoHeight: true,
          cellStyle: {'text-overflow': 'String',
          'border-right':'0.05px solid'
        },
          
       //   editable: true,
          resizable: true,
          suppressSizeToFit: false,
          filter:true,
          sortable:true,
        },
        pinnedBottomRowData:null,
        getRowStyle: function (params) {
          if (params.node.rowPinned) {
            return { 'font-weight': 'bold' };
          }
        },
      rowData: null, 
      openPostionTotal:0,
      filledPositionTotal:0,
      profReceivedTotal:0,
      profSubmittedTotal:0,
      pendingClientTotal:0,
      rejClientTotal:0,
      selectedRows:null,
      startDate: this.getStartDate(),
      endDate: this.getEndDate(),
      };
    }

     onFilterChanged=(ev)=>{
      
      if (ev?.api?.rowModel?.rowsToDisplay) {
        this.setState({ selectedRows: ev?.api?.rowModel?.rowsToDisplay.filter(node => node.data) });
      }
       
      let opentot =0;
      let filledtot =0;
      let profReceived =0;
      let profSubmitted=0;
      let pendClient =0;
      let rejClient=0;
      for(var i=0; i<this.state.selectedRows.length; i++)
      {
        opentot = opentot+ this.state.selectedRows[i].data.totalopenPositions;
        filledtot = filledtot+ this.state.selectedRows[i].data.totalfilledPositions;
        profReceived = profReceived +this.state.selectedRows[i].data.totalprofilesReceived;
        profSubmitted = profSubmitted + this.state.selectedRows[i].data.totalprofilesSubmitted;
        pendClient = pendClient + this.state.selectedRows[i].data.totalpendClientInterview;
        rejClient = rejClient+this.state.selectedRows[i].data.totalclientRejected;
      }
      let Val=[];
      Val.push({primarySkills:'Total',totalopenPositions:opentot,
        totalfilledPositions:filledtot,totalprofilesReceived:profReceived,
        totalprofilesSubmitted:profSubmitted,totalpendClientInterview:pendClient,
        totalclientRejected:rejClient});

      this.setState({ pinnedBottomRowData:Val,openPostionTotal:opentot,
        filledPositionTotal: filledtot,
        profReceivedTotal:profReceived,
        profSubmittedTotal:profSubmitted,
        pendingClientTotal:pendClient,
        rejClientTotal:rejClient
      });
    }
  componentDidMount() {
    fetch('https://rsmbackend.be/requirement/home')
    .then(res => res.json())
    .then(rowData => {
      let opentot =0;
      let filledtot =0;
      let profReceived =0;
      let profSubmitted=0;
      let pendClient =0;
      let rejClient=0;
      for(var i=1; i<rowData.length; i++)
      {
        opentot = opentot+ rowData[i].totalopenPositions;
        filledtot = filledtot+ rowData[i].totalfilledPositions;
        profReceived = profReceived +rowData[i].totalprofilesReceived;
        profSubmitted = profSubmitted + rowData[i].totalprofilesSubmitted;
        pendClient = pendClient + rowData[i].totalpendClientInterview;
        rejClient = rejClient+rowData[i].totalclientRejected;
      }
      let Val=[];
      Val.push({primarySkills:'Total',totalopenPositions:opentot,
        totalfilledPositions:filledtot,totalprofilesReceived:profReceived,
        totalprofilesSubmitted:profSubmitted,totalpendClientInterview:pendClient,
        totalclientRejected:rejClient});

      this.setState({ rowData,pinnedBottomRowData:Val,openPostionTotal:opentot,
        filledPositionTotal: filledtot,
        profReceivedTotal:profReceived,
        profSubmittedTotal:profSubmitted,
        pendingClientTotal:pendClient,
        rejClientTotal:rejClient
      });
    })
    .catch(err => console.log(err));

  }
  getStartDate = () => {
    return new Date().toISOString().slice(0, 10)
  }
  getEndDate = () => {
    return new Date().toISOString().slice(0, 10)
  }
  updateStartDate =(e) => {
    this.setState({
      startDate : e.target.value
    });
  }
  updateEndDate = (e) => {
    this.setState({
      endDate : e.target.value
    });
  }
    render() {
      let gridApi;
      const onGridReady=params=>{
        this.gridApi=params.api;
        this.gridColumnApi = params.columnApi;
        //params.api.sizeColumnsToFit();
      }
      const onFirstDataRendered=params=> {
        console.log('onFirstDataRendered');
        this.gridApi.sizeColumnsToFit();        
      }
      const onExportClick=()=>{
        this.gridApi.exportDataAsCsv({
          fileName: 'Resourcing Dashboard',
          sheetName: 'Resourcing Dashboard',
          exportType: 'CurrentPage',
            header:{
              bold: true,
              fontColor: '#00ff00',
              fontSize :32
            }
          }
        );
      }
      return (
        <div className="homeAlign" height='100%' width='100%'>
          <div>
           <span className="startDateAlign">             
             <label htmlFor="startDate" id="lblStartDate">Start Date: </label>
           <input type="date" id="startDate" value={this.state.startDate} onChange={this.updateStartDate}/>
           </span>
           <span className="endDateAlign">
             <label htmlFor="endDate" id="lblEndtDate">End Date: </label>
           <input type="date" id="endDate" value={this.state.endDate} onChange={this.updateEndDate}/>
           </span>

          <span className="expSummaryAlign">
          <IconButton color="primary" aria-label="upload picture" component="span"
           style={{fontSize:15, height:"5%"}} onClick={()=>onExportClick()}>
          <CloudDownload></CloudDownload>Export
        </IconButton>
        </span>
        </div>
        <div 
          className="ag-theme-alpine"
          style={{
            height: '500px',
            width: 'auto',
            marginTop:'1.5%',
            marginLeft:'7%',
            marginRight:'7%',
            marginBottom:'10%'
            }}
          >
          <AgGridReact
            columnDefs={this.state.columnDefs}
            defaultColDef={this.state.defaultColDef}
            autoGroupColumnDef={this.state.autoGroupColumnDef}
            rowData={this.state.rowData}
            enableBrowserTooltips={true}
            rowSelection="multiple"
            getRowStyle={this.state.getRowStyle}
            gridOptions={{headerHeight:80}}
            onGridReady={onGridReady}
            onFirstDataRendered={onFirstDataRendered}
           onFilterChanged={this.onFilterChanged}
           pinnedBottomRowData={this.state.pinnedBottomRowData}
            groupSelectsChildren={true}>
          </AgGridReact>
        </div>
        
        </div>
      );
    }
  }



export default HomeDashboard;