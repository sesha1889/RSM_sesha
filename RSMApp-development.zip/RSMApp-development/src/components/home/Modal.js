import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.css';



class Modal extends Component {
    constructor(props) {
        super(props);
        this.handleSave = this.handleSave.bind(this);
        //this.clientHandler=this.clientHandler.bind(this);
        this.receivedHandler=this.receivedHandler.bind(this);
        this.skillHandler=this.skillHandler.bind(this);
        this.openHandler=this.openHandler.bind(this);
        this.filledHandler=this.filledHandler.bind(this);
        this.waitingHandler=this.waitingHandler.bind(this);
        this.submittedHandler=this.submittedHandler.bind(this);
        this.rejectedHandler=this.rejectedHandler.bind(this);
        this.compData=this.props.rowSet.rowData;
        this.index=this.props.rowSet.requiredData;
        this.indexData=this.compData[this.index];
        this.state={};
    }

    /*componentWillReceiveProps(nextProps) {
        this.setState({
            Client: nextProps.Client,
            Labels: nextProps.Labels,
            Open: nextProps.Open,
            Filled: nextProps.Filled,
            Recieved: nextProps.Recieved,
            Waiting: nextProps.Waiting,
            Submitted: nextProps.Submitted,
            Rejected: nextProps.Rejected
        });
    }

    clientHandler=(e)=> {
        let tempClient=this.state.Client;
        tempClient=e.target.value;
        this.indexData.Client=tempClient;
        this.setState({ Client: tempClient });
    }*/

    skillHandler=(e)=> {
        let tempLabels=this.state.primarySkills;
        tempLabels=e.target.value;
        this.indexData.primarySkills=tempLabels;
        this.setState({ primarySkills: tempLabels });
    }

    openHandler=(e)=> {
        let tempOpen=this.state.totalopenPositions;
        tempOpen=e.target.value;
        this.indexData.totalopenPositions=tempOpen;
        this.setState({ totalopenPositions: tempOpen });
    }

    filledHandler=(e)=> {
        let tempFilled=this.state.totalfilledPositions;
        tempFilled=e.target.value;
        this.indexData.totalfilledPositions=tempFilled;
        this.setState({ totalfilledPositions: tempFilled });
    }

    receivedHandler=(e)=> {
        let tempRecieved=this.state.totalprofilesReceived;
        tempRecieved=e.target.value;
        this.indexData.totalprofilesReceived=tempRecieved;
        this.setState({ totalprofilesReceived: tempRecieved });
    }

    waitingHandler=(e)=> {
        let tempWaiting=this.state.totalpendClientInterview;
        tempWaiting=e.target.value;
        this.indexData.totalpendClientInterview=tempWaiting;
        this.setState({ totalpendClientInterview: tempWaiting });
    }

    submittedHandler=(e)=> {
        let tempSubmitted=this.state.totalprofilesSubmitted;
        tempSubmitted=e.target.value;
        this.indexData.totalprofilesSubmitted=tempSubmitted;
        this.setState({ totalprofilesSubmitted: tempSubmitted });
    }

    rejectedHandler=(e)=> {
        let tempRejected=this.state.totalclientRejected;
        tempRejected=e.target.value;
        this.indexData.totalclientRejected=tempRejected;
        this.setState({ totalclientRejected: tempRejected });
    }

    handleSave=(e)=> {
        console.log(this.index);
        const entry = this.indexData;
        //const entryIndex=this.state.requiredData;
        console.log(entry)
        
        this.props.saveModalDetails(entry,this.index);
    }
    

    render() {
        console.log('entered into Modal')

        if(this.props.rowSet!==undefined && this.props.rowSet.rowData!==undefined && Object.keys(this.props.rowSet.rowData).length!==0){
            const tempIndex=this.props.rowSet.requiredData;
            const tempRow=this.props.rowSet.rowData[tempIndex];
            this.indexData=tempRow;
            console.log(this.props.rowSet.rowData)
            console.log(this.props.rowSet.requiredData);
            console.log(this.indexData);
            this.state=tempRow;
            console.log(this.state);
        return (
            <div className="modal fade" id="exampleModal" tabIndex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div className="modal-dialog" role="document">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="exampleModalLabel">Edit Your Data</h5>
                            <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div className="modal-body">
                            
                            <p><span className="modal-lable">Skill:</span><input type='text' value={this.indexData.primarySkills} onChange={this.skillHandler}/></p>
                            <p><span className="modal-lable">Open:</span><input type='text' value={this.indexData.totalopenPositions} onChange={this.openHandler} /></p>
                            <p><span className="modal-lable">Filled:</span><input type='text' value={this.indexData.totalfilledPositions} onChange={this.filledHandler} /></p>
                            <p><span className="modal-lable">Recieved:</span><input type='text' value={this.indexData.totalprofilesReceived} onChange={this.receivedHandler} /></p>
                            <p><span className="modal-lable">Waiting:</span><input type='text' value={this.indexData.totalpendClientInterview} onChange={this.waitingHandler} /></p>
                            <p><span className="modal-lable">Submitted:</span><input type='text' value={this.indexData.totalprofilesSubmitted} onChange={this.submittedHandler} /></p>
                            <p><span className="modal-lable">Rejected:</span><input type='text' value={this.indexData.totalclientRejected} onChange={this.rejectedHandler} /></p>
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="button" className="btn btn-primary" data-dismiss="modal" onClick={(e) => { this.handleSave(e) }}>Save changes</button>
                        </div>
                    </div>
                </div>
            </div>
        );
        }
        else{
            return (
                <div className="modal fade" id="exampleModal" tabIndex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div className="modal-dialog" role="document">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title" id="exampleModalLabel">Edit Your Data</h5>
                                <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="button" className="btn btn-primary" data-dismiss="modal" onClick={(e) => { this.handleSave(e) }}>Save changes</button>
                            </div>
                        </div>
                    </div>
                </div>
            );
        }
    }
}

export default Modal;