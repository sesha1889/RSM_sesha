import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import DatePicker from "react-datepicker";
import Moment from "moment";
import "react-datepicker/dist/react-datepicker.css";
import './reqDetails.css';


class Modal extends Component {
    constructor(props) {
        super(props);
        this.handleSave = this.handleSave.bind(this);        
        this.compData=this.props.rowSet.rowData;
        this.index=this.props.rowIx;
        this.indexData=this.compData[this.index];
        this.state={};

    }

    requirementId=(e)=> {
        let tempLabels=this.state.requirementId;
        tempLabels=e.target.value;
        this.indexData.requirementId=tempLabels;
        this.setState({ requirementId: tempLabels });
    }

    openDate=(date)=> {
        let tempOpen=this.state.openDate;
        tempOpen=Moment(date).format("MM-DD-YYYY");
        this.indexData.openDate=tempOpen;
        this.setState({ openDate: tempOpen });
    }

    winzoneID=(e)=> {
        let tempFilled=this.state.winzoneID;
        tempFilled=e.target.value;
        this.indexData.winzoneID=tempFilled;
        this.setState({ winzoneID: tempFilled });
    }

    statementOrder=(e)=> {
        let tempRecieved=this.state.statementOrder;
        tempRecieved=e.target.value;
        this.indexData.statementOrder=tempRecieved;
        this.setState({ statementOrder: tempRecieved });
    }

    primarySkills=(e)=> {
        let tempWaiting=this.state.primarySkills;
        tempWaiting=e.target.value;
        this.indexData.primarySkills=tempWaiting;
        this.setState({ primarySkills: tempWaiting });
    }

    department=(e)=> {
        let tempSubmitted=this.state.department;
        tempSubmitted=e.target.value;
        this.indexData.department=tempSubmitted;
        this.setState({ department: tempSubmitted });
    }

    jobTitle=(e)=> {
        let tempRejected=this.state.jobTitle;
        tempRejected=e.target.value;
        this.indexData.jobTitle=tempRejected;
        this.setState({ jobTitle: tempRejected });
    }

    jobdescripiton=(e)=> {
        let tempLabels=this.state.jobDescription;
        tempLabels=e.target.value;
        this.indexData.jobDescription=tempLabels;
        this.setState({ jobDescription: tempLabels });
    }

    startDate=(date)=> {
        let tempOpen=this.state.startDate;
        tempOpen=Moment(date).format("MM-DD-YYYY");
        this.indexData.startDate=tempOpen;
        this.setState({ startDate: tempOpen });
    }

    duration=(e)=> {
        let tempFilled=this.state.durationPeriod;
        tempFilled=e.target.value;
        this.indexData.durationPeriod=tempFilled;
        this.setState({ durationPeriod: tempFilled });
    }

    clientRate=(e)=> {
        let tempRecieved=this.state.clientRate;
        tempRecieved=e.target.value;
        this.indexData.clientRate=tempRecieved;
        this.setState({ clientRate: tempRecieved });
    }

    vendorRate=(e)=> {
        let tempWaiting=this.state.vendorRate;
        tempWaiting=e.target.value;
        this.indexData.vendorRate=tempWaiting;
        this.setState({ vendorRate: tempWaiting });
    }

    openPosition=(e)=> {
        let tempSubmitted=this.state.openPosition;
        tempSubmitted=e.target.value;
        this.indexData.openPosition=tempSubmitted;
        this.setState({ openPosition: tempSubmitted });
    }

    filledPositions=(e)=> {
        let tempRejected=this.state.filledPositions;
        tempRejected=e.target.value;
        this.indexData.filledPositions=tempRejected;
        this.setState({ filledPositions: tempRejected });
    }

    profilesReceived=(e)=> {
        let tempLabels=this.state.profilesReceived;
        tempLabels=e.target.value;
        this.indexData.profilesReceived=tempLabels;
        this.setState({ profilesReceived: tempLabels });
    }

    profilesSubmitted=(e)=> {
        let tempOpen=this.state.profilesSubmitted;
        tempOpen=e.target.value;
        this.indexData.profilesSubmitted=tempOpen;
        this.setState({ profilesSubmitted: tempOpen });
    }

    pendClientInterview=(e)=> {
        let tempFilled=this.state.pendClientInterview;
        tempFilled=e.target.value;
        this.indexData.pendClientInterview=tempFilled;
        this.setState({ pendClientInterview: tempFilled });
    }

    clientRejected=(e)=> {
        let tempRecieved=this.state.clientRejected;
        tempRecieved=e.target.value;
        this.indexData.clientRejected=tempRecieved;
        this.setState({ clientRejected: tempRecieved });
    }

    resourceStatus=(e)=> {
        let tempWaiting=this.state.resourceInformation;
        tempWaiting.resourceStatus=e.target.value;
        this.indexData.resourceStatus=tempWaiting.resourceStatus;
        this.indexData.resourceInformation=tempWaiting;
        this.setState({resourceInformation:tempWaiting});
    }

    resourceName=(e)=> {
        let tempSubmitted=this.state.resourceInformation;
        tempSubmitted.resourceName=e.target.value;
        this.indexData.resourceName=tempSubmitted.resourceName;
        this.indexData.resourceInformation=tempSubmitted;
        this.setState({resourceInformation:tempSubmitted});
    }

    discussionPoints=(e)=> {
        let tempRejected=this.state.resourceInformation;
        tempRejected.discussionPoints=e.target.value;
        this.indexData.discussionPoints=tempRejected.discussionPoints;
        this.indexData.resourceInformation=tempRejected;
        
        this.setState({ resourceInformation: tempRejected });
    }

    status=(e)=> {
        let tempStatus=this.state.requirementSts;
        tempStatus=e.target.value;
        this.indexData.requirementSts=tempStatus;
        
        this.setState({ requirementSts: tempStatus });
    }

    handleSave=(e)=> {
        console.log(this.index);        
        const entry = this.state;
        //const entryIndex=this.state.requiredData;
        console.log(entry);
        const requirementId=entry.requirementId;
        const winzoneID=entry.winzoneID;
        const statementOrder=entry.statementOrder;

        console.log(requirementId, winzoneID, statementOrder);
        if (requirementId.trim().length === 0
    ) {
      alert('Request ID is mandatory!');
      
    }
    else{
        this.props.saveModalDetails(entry,this.index);
    }
    
    }
    

    render() {
        console.log('entered into Modal' +this.props.eId)

        if((!this.props.eId) && this.props.rowSet!==undefined && this.props.rowSet.rowData!==undefined && Object.keys(this.props.rowSet.rowData).length!==0){
            const tempIndex=this.props.rowSet.requiredData;
            let tempRow=this.props.rowSet.rowData[tempIndex];
            if(Array.isArray(tempRow.resourceInformation)){
                console.log(tempRow.resourceInformation)
                let tempRes=tempRow.resourceInformation[0];
                tempRow.resourceInformation=tempRes;
                tempRow.resourceName=tempRes.resourceName;
                tempRow.resourceStatus=tempRes.resourceStatus;
                tempRow.discussionPoints=tempRes.discussionPoints;
            }
            else if(tempRow.resourceInformation===undefined||Object.keys(tempRow.resourceInformation).length === 0){
                let tempRes={};
                console.log(tempRow.resourceInformation);
                tempRow.resourceInformation=tempRes;
                tempRow.resourceName='';
                tempRow.resourceStatus='';
                tempRow.discussionPoints='';
            }
            this.indexData=tempRow;
            console.log(this.props.rowSet.rowData)
            console.log(this.props.rowSet.requiredData);
            console.log(this.indexData);
            this.state=tempRow;       
            console.log(this.state);
            
        return (
            <div className="modal fade" id="exampleModal" tabIndex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" data-keyboard="false" data-backdrop="static">
                <div className="modal-dialog" role="document">
                    <div className="reqmodal-content">
                        <div><div className="modal-header">
                            <h5 className="modal-title" id="exampleModalLabel">Modify Requirement Details</h5>
                            <button type="button" className="close" data-dismiss="modal" aria-label="Close" onClick={(e) => {this.props.closeModal(e) }}>
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div></div>
                        <div className="reqmodal-body">
                        <div><div className="modal-content">
                        <tr className="table"><th><span className="modal-lable">Beeline Request ID:</span><input readOnly type='text' value={this.indexData.requirementId} onChange={this.requirementId.bind(this)}/></th>
                            <th><span className="modal-lable">Open Week:</span><DatePicker dateFormat="YYYY-MM-DD" minDate={new Date()} filterDate={date => {const day = date.getDay(); return day=== 5;}} type='text' value={this.indexData.openDate} onChange={this.openDate.bind(this)} /></th>
                            <th><span className="modal-lable">Winzone:</span><input type='text' value={this.indexData.winzoneID} onChange={this.winzoneID.bind(this)} /></th></tr>
                            <tr className="table"><th><span className="modal-lable">SO#:</span><input type='text' value={this.indexData.statementOrder} onChange={this.statementOrder.bind(this)} /></th>
                            <th><span className="modal-lable">Skill:</span><input type='text' value={this.indexData.primarySkills} onChange={this.primarySkills.bind(this)} /></th>
							<th><span className="modal-lable">Department:</span><input type='text' value={this.indexData.department} onChange={this.department.bind(this)} /></th></tr>
                            <tr className="table"><th><span className="modal-lable">Title:</span><input type='text' value={this.indexData.jobTitle} onChange={this.jobTitle.bind(this)} /></th>
                            <th><span className="modal-lable">Job Description:</span><input type='text' value={this.indexData.jobDescription} onChange={this.jobdescripiton.bind(this)} /></th>
							<th><span className="modal-lable">Start Date:</span><DatePicker dateFormat="YYYY-MM-DD" minDate={new Date()} filterDate={date => {const day = date.getDay(); return day !== 0 && day !== 6;}} type='text' value={this.indexData.startDate} onChange={this.startDate.bind(this)} /></th></tr>
                            <tr className="table"><th><span className="modal-lable">Duration:</span><input type='text' value={this.indexData.durationPeriod} onChange={this.duration.bind(this)} /></th>
                            <th><span className="modal-lable">Client Rate:</span><input type='text' value={this.indexData.clientRate} onChange={this.clientRate.bind(this)} /></th>
                            <th><span className="modal-lable">Vendor Rate:</span><input type='text' value={this.indexData.vendorRate} onChange={this.vendorRate.bind(this)} /></th></tr>
                            <tr className="table"><th><span className="modal-lable">Open  Positions:</span><input type='text' value={this.indexData.openPosition} onChange={this.openPosition.bind(this)} /></th>
                            <th><span className="modal-lable">Filled Positions:</span><input type='text' value={this.indexData.filledPositions} onChange={this.filledPositions.bind(this)} /></th>
                            <th><span className="modal-lable">Profiles Received:</span><input type='text' value={this.indexData.profilesReceived} onChange={this.profilesReceived.bind(this)} /></th></tr>
							<tr className="table"><th><span className="modal-lable">Submitted Profiles:</span><input type='text' value={this.indexData.profilesSubmitted} onChange={this.profilesSubmitted.bind(this)} /></th>
							<th><span className="modal-lable">Waiting for Client Interview:</span><input type='text' value={this.indexData.pendClientInterview} onChange={this.pendClientInterview.bind(this)} /></th>
                            <th><span className="modal-lable">Rejected by Client:</span><input type='text' value={this.indexData.clientRejected} onChange={this.clientRejected.bind(this)} /></th></tr>
                            <tr className="table"><th><span className="modal-lable">Resource Status:</span><input type='text' value={this.indexData.resourceStatus} onChange={this.resourceStatus.bind(this)} /></th>
                            <th><span className="modal-lable">Resource Name:</span><input type='text' value={this.indexData.resourceName} onChange={this.resourceName.bind(this)} /></th>
                            <th><span className="modal-lable">Discussion Points:</span><input type='text' value={this.indexData.discussionPoints} onChange={this.discussionPoints.bind(this)} /></th></tr>
                            <tr className="table"><th className="modal-lable">Beeline Status:</th><th>
                                            <select value={this.indexData.requirementSts} onChange={this.status.bind(this)}>
                                                <option value="open">Open</option>
                                                <option value="hold">Hold</option>
                                                <option value="closed">Closed</option>
                                            </select></th></tr>
                            </div>
                        </div>
                        <div className="modal-footer">
                            
                            <button type="button" className="btn btn-primary" onClick={(e) => {this.handleSave(e) }}>Update Requirement</button>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        );
        }
        else if(this.props.eId && this.props.rowSet!==undefined && this.props.rowSet.rowData!==undefined && Object.keys(this.props.rowSet.rowData).length!==0){
            const tempIndex=this.props.rowSet.requiredData;
            let tempRow=this.props.rowSet.rowData[tempIndex];
            if(Array.isArray(tempRow.resourceInformation)){
                console.log(tempRow.resourceInformation)
                let tempRes=tempRow.resourceInformation[0];
                tempRow.resourceInformation=tempRes;
            }
            else if(tempRow.resourceInformation===undefined){
                let tempRes={};
                console.log(tempRow.resourceInformation);
                tempRow.resourceInformation=tempRes;
            }
            console.log(tempRow.resourceInformation);
            this.indexData=tempRow;
            
            console.log(this.props.rowSet.rowData)
            console.log(this.props.rowSet.requiredData);
            console.log(this.indexData);
            this.state=tempRow;       
            console.log(this.state);
            return (
                <div className="modal fade" id="exampleModal" tabIndex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div className="modal-dialog" role="document">
                        <div className="reqmodal-content">
                            <div className="modal-header">
                                <h5 className="modal-title" id="exampleModalLabel">Enter New Requirement Details</h5>
                                <button type="button" className="close" data-dismiss="modal" aria-label="Close" onClick={(e) => {this.props.closeModal(e) }}>
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div className="reqmodal-body">
                        <div><div className="modal-content">
                        <tr className="table"><th><span className="modal-lable">Request ID:</span><input type='text' value={this.indexData.requirementId} onChange={this.requirementId.bind(this)}/></th>
                            <th><span className="modal-lable">Open Week:</span><DatePicker dateFormat="YYYY-MM-DD" minDate={new Date()} filterDate={date => {const day = date.getDay(); return day=== 5;}} type='text' value={this.indexData.openDate} onChange={this.openDate.bind(this)} /></th>
                            <th><span className="modal-lable">Winzone:</span><input type='text' value={this.indexData.winzoneID} onChange={this.winzoneID.bind(this)} /></th></tr>
                            <tr className="table"><th><span className="modal-lable">SO#:</span><input type='text' value={this.indexData.statementOrder} onChange={this.statementOrder.bind(this)} /></th>
                            <th><span className="modal-lable">Skill:</span><input type='text' value={this.indexData.primarySkills} onChange={this.primarySkills.bind(this)} /></th>
							<th><span className="modal-lable">Department:</span><input type='text' value={this.indexData.department} onChange={this.department.bind(this)} /></th></tr>
                            <tr className="table"><th><span className="modal-lable">Title:</span><input type='text' value={this.indexData.jobTitle} onChange={this.jobTitle.bind(this)} /></th>
                            <th><span className="modal-lable">Job Description:</span><input type='text' value={this.indexData.jobDescription} onChange={this.jobdescripiton.bind(this)} /></th>
							<th><span className="modal-lable">Start Date:</span><DatePicker dateFormat="YYYY-MM-DD" minDate={new Date()} filterDate={date => {const day = date.getDay(); return day !== 0 && day !== 6;}} type='text' value={this.indexData.startDate} onChange={this.startDate.bind(this)} /></th></tr>
                            <tr className="table"><th><span className="modal-lable">Duration:</span><input type='text' value={this.indexData.durationPeriod} onChange={this.duration.bind(this)} /></th>
                            <th><span className="modal-lable">Client Rate:</span><input type='text' value={this.indexData.clientRate} onChange={this.clientRate.bind(this)} /></th>
                            <th><span className="modal-lable">Vendor Rate:</span><input type='text' value={this.indexData.vendorRate} onChange={this.vendorRate.bind(this)} /></th></tr>
                            <tr className="table"><th><span className="modal-lable">Open  Positions:</span><input type='text' value={this.indexData.openPosition} onChange={this.openPosition.bind(this)} /></th>
                            <th><span className="modal-lable">Filled Positions:</span><input type='text' value={this.indexData.filledPositions} onChange={this.filledPositions.bind(this)} /></th>
                            <th><span className="modal-lable">Profiles Received:</span><input type='text' value={this.indexData.profilesReceived} onChange={this.profilesReceived.bind(this)} /></th></tr>
							<tr className="table"><th><span className="modal-lable">Submitted Profiles:</span><input type='text' value={this.indexData.profilesSubmitted} onChange={this.profilesSubmitted.bind(this)} /></th>
							<th><span className="modal-lable">Waiting for Client Interview:</span><input type='text' value={this.indexData.pendClientInterview} onChange={this.pendClientInterview.bind(this)} /></th>
                            <th><span className="modal-lable">Rejected by Client:</span><input type='text' value={this.indexData.clientRejected} onChange={this.clientRejected.bind(this)} /></th></tr>
                            <tr className="table"><th><span className="modal-lable">Resource Status:</span><input type='text' value={this.indexData.resourceStatus} onChange={this.resourceStatus.bind(this)} /></th>
                            <th><span className="modal-lable">Resource Name:</span><input type='text' value={this.indexData.resourceName} onChange={this.resourceName.bind(this)} /></th>
                            <th><span className="modal-lable">Discussion Points:</span><input type='text' value={this.indexData.discussionPoints} onChange={this.discussionPoints.bind(this)} /></th></tr>
                            <tr className="table"><th className="modal-lable">Beeline Status:</th><th><input type='text' value='Open' readOnly/></th></tr>
                            </div>
                        </div></div>
                            <div className="modal-footer">
                                
                                <button type="button" className="btn btn-primary" onClick={(e) => {this.handleSave(e)}}>Add Requirement</button>
                            </div>
                        </div>
                    </div>
                </div>
            );
        }
        else{
            return (
                <div className="modal fade" id="exampleModal" tabIndex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div className="modal-dialog" role="document">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title" id="exampleModalLabel">Edit Your Data</h5>
                                <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            
                            <div className="modal-footer">
                                <button type="button" className="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="button" className="btn btn-primary" data-dismiss="modal">Save changes</button>
                            </div>
                        </div>
                    </div>
                </div>
            );
        }
    }
}

export default Modal;