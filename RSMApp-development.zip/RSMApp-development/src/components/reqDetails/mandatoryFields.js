const fieldValidations = [{
		"fieldName": "requirementId",
		"fieldType": "String",
		"screenName": "Beeline Request ID"
	}, {
		"fieldName": "openDate",
		"fieldType": "String",
		"screenName": "Open Week"
	}, {
		"fieldName": "statementOrder",
		"fieldType": "Number",
		"screenName": "SO#"
	}, {
		"fieldName": "department",
		"fieldType": "String",
		"screenName": "Department"
	}, {
		"fieldName": "jobTitle",
		"fieldType": "String",
		"screenName": "Title"
	}, {
		"fieldName": "jobDescription",
		"fieldType": "String",
		"screenName": "Job Description"
	}, {
		"fieldName": "startDate",
		"fieldType": "String",
		"screenName": "Start date"
	}, {
		"fieldName": "duration",
		"fieldType": "String",
		"screenName": "Duration"
	}, {
		"fieldName": "requirementSts",
		"fieldType": "String",
		"screenName": "Status"
	}, {
		"fieldName": "clientRate",
		"fieldType": "Number",
		"screenName": "Client Rate"
	}, {
		"fieldName": "openPosition",
		"fieldType": "Number",
		"screenName": "Open Positions"
	}]
export default fieldValidations;