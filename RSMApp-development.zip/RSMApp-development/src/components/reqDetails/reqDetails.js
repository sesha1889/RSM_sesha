import React from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/dist/styles/ag-grid.css";
import "ag-grid-community/dist/styles/ag-theme-alpine.css";
import axios from "axios";
import Moment from "moment";
import ReqModal from "./reqModal";
//import 'jquery/dist/jquery.min.js';
import "popper.js/dist/popper.min.js";
import "bootstrap/dist/js/bootstrap.min.js";
import "./reqDetails.css";
import IconButton from "@material-ui/core/IconButton";
import CloudDownload from "@material-ui/icons/CloudDownload";

class reqDetails extends React.Component {
  sampArray = [];
  currentReqSts = "open";
  constructor(props) {
    super(props);
    this.changerequiredData = this.changerequiredData.bind(this);
    this.saveModalDetails = this.saveModalDetails.bind(this);
    this.onGridReady = this.onGridReady.bind(this);
    this.mouseOver = this.mouseOver.bind(this);
    this.addReq = false;
    this.state = {
      columnDefs: [],
      rowData: [],
      tempRowData: [],
      autoGroupColumnDef: {
        headerName: "Request ID",
        field: "requirementId",
        cellRenderer: "agGroupCellRenderer",
      },
      frameworkComponents: {},
      requiredData: 0,
      defaultColDef: {
        flex: 1,
        minWidth: '80',
        maxWidth:'175',
        //maxRowHeight:'90',
        cellClass: 'cell-wrap-text',
        //autoHeight: true,
        cellStyle: {'text-overflow': 'String',
        'border-right':'0.05px solid'},
     //   editable: true,
        resizable: true,
        filter: true,
        suppressSizeToFit: false,
        sortable: true,
      },
      // rowHeight: 275,
      addRequest: false,
    };
  }

  componentDidMount() {
    this.setState({
      columnDefs: this.getRequirementColDef(),
      rowData: this.getRequirementDetails(),
    });
  }

  mouseOver(event) {
    this.setState({ requiredData: event.rowIndex });
  }

  getRequirementColDef() {
    return [
      {
        headerName: "Beeline Request ID",
        field: "requirementId",
        suppressSizeToFit: true,
        cellRenderer: function (params) {
          return (
            `<a data-toggle="modal" href="#exampleModal">` +
            params.value +
            `</a>`
          );
        },
        //cellRendererParams: {},
        //width: 10,
      },
      { headerName: "Open Week", field: "openDate" },
      { headerName: "Skill", field: "primarySkills", tooltipField: "primarySkills" },
      { headerName: "Title", field: "jobTitle" ,tooltipField: "jobTitle"},
      { headerName: "Job Description", field: "jobDescription",tooltipField: "jobDescription" },
      { headerName: "Start Date", field: "startDate" },
      { headerName: "Duration", field: "durationPeriod" },
      { headerName: "Client Rate", field: "clientRate", cellClass: "reqDtl-cell-right"},
      { headerName: "Vendor Rate", field: "vendorRate", cellClass: "reqDtl-cell-right"},
      { headerName: "Lowe's Department", field: "department", tooltipField: "department" },
      { headerName: "Requirement Status", field: "requirementSts",headerTooltip:"Status"  },
      { headerName: "Winzone", field: "winzoneID" },
      { headerName: "SO#", field: "statementOrder", cellClass: "reqDtl-cell-right"},
      { headerName: "Resource Status", field: "resourceStatus", tooltipField: "resourceStatus" },
      { headerName: "Resource Name", field: "resourceName", tooltipField: "resourceName" },
      { headerName: "Comments", field: "discussionPoints", tooltipField: "discussionPoints" } ,
      { headerName: "Open Positions", field: "openPosition",headerTooltip:"Open Positions", cellClass: "reqDtl-cell-right"  },
      { headerName: "Filled Positions", field: "filledPositions", headerTooltip:"Filled Positions",cellClass: "reqDtl-cell-right"  },
      { headerName: "Profiles Received", field: "profilesReceived",headerTooltip:"Profiles Received", cellClass: "reqDtl-cell-right"  },
      { headerName: "Submitted Profiles", field: "profilesSubmitted", headerTooltip:"Submitted Profiles",cellClass: "reqDtl-cell-right"  },
      { headerName: "Waiting for Client Interview", field: "pendClientInterview",headerTooltip:"Waiting for Client Interview",cellClass: "reqDtl-cell-right"  },
      { headerName: "Rejected by Client", field: "clientRejected", headerTooltip:"Rejected by Client",cellClass: "reqDtl-cell-right"  }    
    ];
  }

  getRequirementDetails() {
    const reqStatus = this.currentReqSts;
    //   console.log(`Updating page for requirement status,  ${reqStatus}`);
    // axios.get(`http://localhost:4000/requirements/${reqStatus}`)
    axios
      .get(`https://rsmbackend.be/requirement/${reqStatus}`)
      .then((response) => {
        //console.log(JSON.stringify(response));

        /**
         * For MVP - Resouorce information is going to be shown as free form text,
         * so the nested resource information is taken from response object and mapped to table.
         */
        //     let dupObj = JSON.stringify(response);
        if (!response.data[0] || response.data.length === 0) {
          alert("No requirements for selected status");
        }
        let respArr = [];
        let respObj = {};
        for (var idx in response.data) {
          let sdate = response.data[idx].startDate;
          let odate = response.data[idx].openDate;
          response.data[idx].startDate = Moment.utc(sdate).format("MM-DD-YYYY");
          response.data[idx].openDate = Moment.utc(odate).format("MM-DD-YYYY");
          respObj = {
            ...response.data[idx],
            ...response.data[idx].resourceInformation,
          };
          respArr.push(respObj);
          //   console.log(response.data[idx]);
        }
        console.log(respArr);
        this.setState({
          rowData: [...respArr],
        });
      })
      .catch((err) => {
        console.log(err);
        return alert(
          "Error loading requirement for current status",
          "Resource Management"
        );
      });
  }

  addNewRequest = () => {
    this.addReq = true;
    let rowCnt = this.state.rowData.length;
    this.sampArray = [...this.state.rowData];
    this.sampArray.splice(rowCnt, 0, this.createNewRecord());
    rowCnt = this.sampArray.length;
    //this.gridApi.setRowData(this.sampArray);
    console.log("Value of  samp Array", this.sampArray, this.sampArray.length);
    this.setState({
      rowData: this.sampArray,
      addRequest: true,
      requiredData: this.sampArray.length - 1,
    });
  };
  handleModalClose = () => {
    console.log("Called Modal CLose");
    this.sampArray = this.state.tempRowData;
    this.sampArray.pop();
    this.addReq = false;
    this.setState({
      tempRowData: this.sampArray,
      addRequest: false,
      requiredData: 0,
    });
    this.getRequirementDetails();
  };
  createNewRecord = () => {
    var obj = {
      requirementId: "",
      openDate: "",
      winzoneID: "",
      statementOrder: "",
      primarySkills: "",
      department: "",
      jobTitle: "",
      jobDescription: "",
      startDate: "",
      durationPeriod: "",
      requirementSts: "Open",
      clientRate: "0",
      vendorRate: "0",
      openPosition: "0",
      filledPositions: "0",
      profilesReceived: "0",
      profilesSubmitted: "0",
      pendClientInterview: "0",
      clientRejected: "0",
      resourceStatus: "",
      resourceName: "",
      resourceInformation: {},
      discussionPoints: "",
    };

    return obj;
  };

  onGridReady = (params) => {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    params.api.sizeColumnsToFit();
  };

  changerequiredData(data) {
    console.log("Im in requiredData");
    console.log(data);
    this.setState({
      requiredData: data,
    });
  }

  saveModalDetails(data, ind) {
    console.log("in save modal");
    console.log(data);
    let tempdetail = this.state.rowData;
    tempdetail[ind] = data;
    let tempRow = data;
    console.log(data.requirementId, data.requirementSts);
    let actualdata = {
      requirementId: tempRow.requirementId,
      openDate: tempRow.openDate,
      statementOrder: tempRow.statementOrder,
      winzoneID: tempRow.winzoneID,
      department: tempRow.department,
      jobTitle: tempRow.jobTitle,
      primarySkills: tempRow.primarySkills,
      jobDescription: tempRow.jobDescription,
      startDate: tempRow.startDate,
      durationPeriod: tempRow.durationPeriod,
      requirementSts: tempRow.requirementSts,
      clientRate: tempRow.clientRate,
      vendorRate: tempRow.vendorRate,
      openPosition: tempRow.openPosition,
      filledPositions: tempRow.filledPositions,
      profilesReceived: tempRow.profilesReceived,
      profilesSubmitted: tempRow.profilesSubmitted,
      pendClientInterview: tempRow.pendClientInterview,
      clientRejected: tempRow.clientRejected,
      resourceInformation: tempRow.resourceInformation,
    };
    console.log(JSON.stringify(actualdata));
    console.log(actualdata);
    if (!this.addReq) {
      axios
        .post(
          `https://rsmbackend.be/requirement/update/${data.requirementId}`,
          actualdata
        )
        .then((response) => {
          console.log(response);
          alert(response.data);
          if (response.status === 200) {
            this.addReq = false;
            this.setState({
              addRequest: false,
              requiredData: 0,
            });
            window.location.reload(true);
          }
        })
        .catch((err) => {
          console.log(err);
          return alert("Error updating Requirement", "Resource Management");
        });

      //document.getElementById("exampleModal").style.display = "none";
    } else {
      console.log("new request add");
      axios
        .post(`https://rsmbackend.be/requirement/add`, actualdata)
        .then((response) => {
          console.log(response);
          alert(response.data);
          if (response.status === 200) {
            this.addReq = false;
            this.setState({
              addRequest: false,
              requiredData: 0,
            });
            window.location.reload(true);
          }
        })
        .catch((err) => {
          console.log(err);
          return alert("Error Adding Requirement", "Resource Management");
        });
    }
    this.setState({
      rowData: tempdetail,
      addRequest: false,
    });
  }

  handleReqSelection = (e) => {
    console.log("Selected request status", e.target.value);
    this.currentReqSts = e.target.value;
    this.getRequirementDetails();
  };
  addControls = () => {
    return (
      <div>
        <input
          type="button"
          value="Create New Position"
          onClick={this.addNewRequest}
          className="alignNewReqBtn btn btn-secondary"
          data-toggle="modal"
          data-target="#exampleModal"
        />
        <div style={{float:"right",paddingRight:"1%"}}>
        <label>Requirement Status: </label>
        <select
          
          id="reqSelection"
          onChange={this.handleReqSelection}
        >
          <option value="open" selected>
            Open
          </option>
          <option value="hold">Hold</option>
          <option value="closed">Closed</option>
          <option value="">All</option>
        </select>
      </div>
      </div>
    );
  };
  onFirstDataRendered=params=> {
    console.log('onFirstDataRendered');
    params.columnApi.autoSizeAllColumns(true);
  };
  onColumnResized = (params) => {
    params.api.resetRowHeights();
  };
  render() {
    const onExportClick = () => {
      this.gridColumnApi.setColumnVisible("Edit", false);
      this.gridApi.exportDataAsCsv({
        fileName: "Requirements",
        sheetName: "Requirements",  
        exportType: "CurrentPage",
        header: {
          bold: true,
          fontColor: "#00ff00",
          fontSize: 32,
        },
      });
      this.gridColumnApi.setColumnVisible("Edit", true);
    };
    return (
      <div style={{ width: "100%", height: "100%", overflowX: "hidden" }}>
        {this.addControls()}
        <div className="expReqAlign">
          <IconButton
            color="primary"
            aria-label="upload picture"
            component="span"
            style={{ fontSize: 15, height: "5%" }}
            onClick={() => onExportClick()}
          >
            <CloudDownload></CloudDownload>Export
          </IconButton>
        </div>
        <div
          className="ag-theme-alpine"
          style={{
            height: "500px",
            width: "97%",
            marginTop: "10px",
            marginLeft: "20px",
          }}
        >
          <AgGridReact
            columnDefs={this.state.columnDefs}
            enableColResize
            autoGroupColumnDef={this.state.autoGroupColumnDef}
            onColumnResized={this.onColumnResized.bind(this)}
            defaultColDef={this.state.defaultColDef}
            rowData={this.state.rowData}
            rowSelection="multiple"
            rowHeight={this.state.rowHeight}
            enableBrowserTooltips={true}
            onGridReady={this.onGridReady}
            onFirstDataRendered={this.onFirstDataRendered.bind(this)}
            gridOptions={{headerHeight:80,
              onCellMouseOver: this.mouseOver,
              context: {
                entry: this.state.rowData,
                modData: this.changerequiredData,
              },
            }}
            groupSelectsChildren={true}
            suppressColumnVirtualisation={true}
            frameworkComponents={this.state.frameworkComponents}
          ></AgGridReact>
          <div>
            <ReqModal
              eId={this.addReq}
              rowIx={this.state.requiredData}
              rowSet={this.state}
              saveModalDetails={this.saveModalDetails}
              closeModal={this.handleModalClose}
            />
          </div>
        </div>
      </div>
    );
  }
}
export default reqDetails;
