import React, {Component} from 'react';
import EditIcon from '@material-ui/icons/Edit';
//import Modal from './Modal';

export default class BtnCellRenderer extends Component {
  constructor(props) {
    super(props);
    this.btnClickedHandler = this.btnClickedHandler.bind(this);
    this.rowind=0;
    this.entrySet=[];
    this.opset=false;
  }
  btnClickedHandler=(e)=>{
    console.log(this.props);
    //e.preventDefault();
    console.log('I\'m in button renderer');
   //this.props.clicked(this.props.rowIndex);
   this.rowind=this.props.rowIndex;
   //this.entrySet=this.props.context.entry;
   //const modVal=this.props.context.modVal;
   //this.opset=true;
   console.log(this.rowind);
   this.props.context.modData(this.rowind);
   //console.log(this.props.context.modVal);
   }

   render(){
     console.log(this.props);
return(
      <button style={{ marginLeft: "auto" }} className="btn btn-primary" data-toggle="modal" href="#exampleModal" 
      onClick={this.btnClickedHandler}><EditIcon></EditIcon></button> )
}  
}